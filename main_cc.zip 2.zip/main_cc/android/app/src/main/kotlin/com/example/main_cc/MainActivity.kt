package com.example.main_cc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
